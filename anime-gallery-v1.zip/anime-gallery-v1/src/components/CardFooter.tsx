import React, { ReactElement } from "react";
import { Button, CardMedia, StyledProps } from "@material-ui/core";
import './CardFooter.css';
import {useSelector} from 'react-redux';
import {RootState} from '../store/store';

interface CardFooterProps {
  buttonClick: () => void;
  containerStyle?: any;
}

const CardFooter = (props: CardFooterProps): ReactElement => {
  const {
    content: {title, logo, subTitle},
  } = useSelector((state: RootState) => state);

  return (
    <div className={`cardBottomContainer ${props.containerStyle}`}>
      <CardMedia className='logo' image={logo} />
      <div>
        <h4 className='title'>{title}</h4>
        <p className='title'>{subTitle}</p>
      </div>
      <Button className='refreshButton' onClick={props.buttonClick}>
        REFRESH
      </Button>
    </div>
  );
};

export default CardFooter;
