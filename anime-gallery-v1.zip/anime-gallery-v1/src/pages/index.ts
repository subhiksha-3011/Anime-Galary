import HomePage from './HomePage';
import DetailsPage from './DetailsPage';

export {HomePage, DetailsPage};
