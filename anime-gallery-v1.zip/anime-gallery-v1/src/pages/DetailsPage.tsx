import React, {ReactElement} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {AppDispatch, RootState, store} from '../store/store';
import '../styles/DetailsPage.css';
import CardFooter from '../components/CardFooter';
import {getAnime} from '../store/slices/details-reducer';
import {ApiStatus} from '../constants/core.constants';
import {useNavigate} from 'react-router-dom';
import {Button} from '@material-ui/core';

const DetailsPage = (): ReactElement => {
  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();
  const {
    token,
    content: {mainImage, subTitle, text},
  } = useSelector((state: RootState) => state);

  const handleRefresh = async () => {
    await dispatch(getAnime(token));
    store.getState().apiStatus === ApiStatus.FAILURE && alert('Api Failed');
  };

  return (
    <div className='outerContainer'>
      <div style={{backgroundImage: `url(${mainImage})`}} className='backgroundImg'>
        <div style={{display: 'flex'}}>
          <div className='updateText'>MAJOR UPDATE</div>
          <div className='material-symbols-outlined close' onClick={() => navigate('/')}>
            close
          </div>
        </div>
        <div className='updateText subTitle'>{subTitle}</div>
      </div>
      <CardFooter buttonClick={handleRefresh} />
      <div className='borderLine' />
      <div className='text' dangerouslySetInnerHTML={{__html: text}} />
      <div className='cardFooter'>
        <CardFooter buttonClick={handleRefresh} containerStyle='columnFooter' />
      </div>
      <Button className='shareButton' onClick={handleRefresh}>
        SHARE STORY
      </Button>
    </div>
  );
};

export default DetailsPage;
