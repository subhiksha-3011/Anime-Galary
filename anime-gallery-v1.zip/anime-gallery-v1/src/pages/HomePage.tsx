import React, {ReactElement, useEffect} from 'react';
import '../styles/HomePage.css';
import {Card, CardMedia} from '@material-ui/core';
import {useNavigate} from 'react-router-dom';
import {useDispatch, useSelector} from 'react-redux';
import {AppDispatch, RootState, store} from '../store/store';
import {getAnime, getToken} from '../store/slices/details-reducer';
import {ApiStatus, emailId} from '../constants/core.constants';
import CardFooter from '../components/CardFooter';

const HomePage = (): ReactElement => {
  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();
  const {
    token,
    content: {thumbNailImage},
  } = useSelector((state: RootState) => state);

  useEffect(() => {
    !token && handleAuth();
  }, []);

  useEffect(() => {
    store.getState().apiStatus && token && !thumbNailImage && getAnimeDetails();
  }, [token]);

  const handleAuth = async () => {
    await dispatch(getToken(emailId));
    store.getState().apiStatus === ApiStatus.FAILURE && alert('Api Failed');
  };

  const getAnimeDetails = async () => {
    await dispatch(getAnime(token));
    store.getState().apiStatus === ApiStatus.FAILURE && alert('Api Failed');
  };

  return (
    <div className='outerContainer'>
      <h4>SATURDAY 18 FEBRUARY</h4>
      <h1>TODAY</h1>
      <Card className='cardContainer'>
        <CardMedia className='image' image={thumbNailImage} onClick={() => navigate('/details')} />
        <CardFooter buttonClick={getAnimeDetails} />
      </Card>
    </div>
  );
};

export default HomePage;
