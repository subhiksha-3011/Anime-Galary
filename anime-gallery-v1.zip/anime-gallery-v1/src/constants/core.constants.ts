export const emailId = 'vsubhiksha1998@gmail.com';

export enum LoadingState {
  TRUE = 'true',
  FALSE = 'false',
}

export enum ApiStatus {
  SUCCESS = 'success',
  FAILURE = 'failure',
}
