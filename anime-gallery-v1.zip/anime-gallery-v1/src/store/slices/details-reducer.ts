import {
  ActionReducerMapBuilder,
  createAsyncThunk,
  createSlice,
  PayloadAction,
} from '@reduxjs/toolkit';
import axios from 'axios';
import {ApiStatus, LoadingState} from '../../constants/core.constants';

interface Content {
  thumbNailImage: string;
  mainImage: string;
  userName: string;
  subTitle: string;
  text: string;
  id: number;
  logo: string;
  title: string;
}

interface stateType {
  token: string;
  loadingState: LoadingState;
  apiStatus: ApiStatus;
  content: Content
}

const initialState: stateType = {
  token: '',
  loadingState: LoadingState.FALSE,
  apiStatus: ApiStatus.FAILURE,
  content: {
    thumbNailImage: '',
    mainImage: '',
    userName: '',
    subTitle: '',
    text: '',
    id: 0,
    logo: '',
    title: 'string',
  },
};

export const getToken = createAsyncThunk('getAuthToken', async (emailId: string, thunkAPI) => {
  try {
    const response = await axios.post(
      'https://swsut62sse.execute-api.ap-south-1.amazonaws.com/prod/generateToken',
      {
        email: emailId,
      }
    );
    return response.data;
  } catch (e: any) {
    return thunkAPI.rejectWithValue(e.data);
  }
});

export const getAnime = createAsyncThunk('getAnime', async (token: string, thunkAPI) => {
  try {
    const response = await axios.get(
      'https://tzab40im77.execute-api.ap-south-1.amazonaws.com/prod/getContent',
      {
        headers: {Authorization: `Bearer ${token}`},
      }
    );
    return response.data;
  } catch (e: any) {
    return thunkAPI.rejectWithValue(e.data);
  }
});

const detailsReducer = createSlice({
  name: 'details',
  initialState,
  reducers: {},
  extraReducers: (builder: ActionReducerMapBuilder<stateType>) => {
    builder
      .addCase(getToken.pending, state => {
        state.loadingState = LoadingState.TRUE;
      })
      .addCase(getToken.fulfilled, (state, action: PayloadAction<{token: string}>) => {
        state.apiStatus = ApiStatus.SUCCESS;
        state.token = action.payload.token;
      })
      .addCase(getToken.rejected, state => {
        state.apiStatus = ApiStatus.FAILURE;
      })
      .addCase(getAnime.fulfilled, (state, action: PayloadAction<{content: Content}>) => {
        state.loadingState = LoadingState.FALSE;
        state.apiStatus = ApiStatus.SUCCESS;
        state.content = action.payload.content;
      })
      .addCase(getAnime.rejected, state => {
        state.loadingState = LoadingState.FALSE;
        state.apiStatus = ApiStatus.FAILURE;
      });
  },
});

export default detailsReducer.reducer;
