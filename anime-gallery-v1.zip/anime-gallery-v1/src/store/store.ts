import {configureStore} from '@reduxjs/toolkit';
import detailsReducer from "./slices/details-reducer";

export const store = configureStore({
  reducer: detailsReducer,
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
