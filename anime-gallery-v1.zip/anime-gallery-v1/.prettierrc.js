module.exports = {
  semi: true,
  tabWidth: 2,
  printWidth: 100,
  singleQuote: true,
  trailingComma: 'es5',
  jsxSingleQuote: true,
  bracketSpacing: false,
  bracketSameLine: true,
  arrowParens: 'avoid',
};
